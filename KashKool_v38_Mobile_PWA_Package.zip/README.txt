KashKool v38 mobile/PWA deployment package

Files:
- index.html: KashKool website
- kashkool.webmanifest: install metadata and icons
- kashkool-sw.js: caches the app shell for repeat/offline launch
- kashkool-icon-192.png and kashkool-icon-512.png: install icons

Deploy all five files together at the root of the same HTTPS site. Do not open only index.html from a file manager if you want installation/offline features: PWA installation and service workers require HTTPS (or localhost).

On Android, open the HTTPS site in Chrome, tap ⋮, then choose Install app (or Add to Home screen) and install/add it.

Data note: this app stores data locally in the browser on each device. This package does not create cloud synchronization between your phone and computer. Export a backup in KashKool before switching browsers/devices.
