$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
$logPath = Join-Path $projectRoot 'BUILD_LAST_LOG.txt'
$exitCode = 0
$transcriptStarted = $false

Set-Location -LiteralPath $projectRoot

try {
    if (Test-Path -LiteralPath $logPath) {
        Remove-Item -LiteralPath $logPath -Force
    }
    Start-Transcript -Path $logPath -Force | Out-Null
    $transcriptStarted = $true

    Write-Host '=========================================='
    Write-Host ' KashKool v70 - Windows build diagnostics'
    Write-Host '=========================================='
    Write-Host "Project folder: $projectRoot"
    Write-Host "Log file: $logPath"
    Write-Host ''

    $nodeCommand = Get-Command 'node.exe' -ErrorAction Stop
    $npmCommand = Get-Command 'npm.cmd' -ErrorAction Stop

    $nodeVersionText = (& $nodeCommand.Source --version).Trim()
    if ($LASTEXITCODE -ne 0 -or $nodeVersionText -notmatch '^v?(\d+)\.(\d+)\.(\d+)') {
        throw 'Could not read the installed Node.js version.'
    }

    $nodeMajor = [int]$Matches[1]
    $nodeMinor = [int]$Matches[2]
    Write-Host "Node.js: $nodeVersionText"

    if ($nodeMajor -lt 20 -or ($nodeMajor -eq 20 -and $nodeMinor -lt 19)) {
        throw 'Node.js 20.19 or newer is required. Node.js 24 LTS is recommended.'
    }

    $npmVersionText = (& $npmCommand.Source --version).Trim()
    if ($LASTEXITCODE -ne 0) {
        throw 'npm was found but could not be started.'
    }
    Write-Host "npm: $npmVersionText"
    Write-Host ''

    Write-Host '[1/3] Installing the pinned build tools.'
    Write-Host 'This step downloads packages and may take a while.'
    Write-Host 'Please keep this window open until it finishes.'
    & $npmCommand.Source install --no-audit --no-fund --verbose
    $commandExitCode = $LASTEXITCODE
    if ($commandExitCode -ne 0) {
        throw "npm install failed with exit code $commandExitCode. Check the network/download error in this log."
    }

    Write-Host ''
    Write-Host '[2/3] Checking project files and JavaScript syntax.'
    & $npmCommand.Source run check
    $commandExitCode = $LASTEXITCODE
    if ($commandExitCode -ne 0) {
        throw "Project checks failed with exit code $commandExitCode."
    }

    Write-Host ''
    Write-Host '[3/3] Building the Windows installer and portable application.'
    & $npmCommand.Source run dist:win
    $commandExitCode = $LASTEXITCODE
    if ($commandExitCode -ne 0) {
        throw "Windows packaging failed with exit code $commandExitCode."
    }

    Write-Host ''
    Write-Host 'BUILD COMPLETED SUCCESSFULLY.'
    Write-Host 'The output files are in the dist folder.'
}
catch {
    $exitCode = 1
    Write-Host ''
    Write-Host '[BUILD ERROR]' -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    Write-Host ''
    Write-Host 'The full diagnostic output is saved in BUILD_LAST_LOG.txt.'
}
finally {
    if ($transcriptStarted) {
        try {
            Stop-Transcript | Out-Null
        }
        catch {
            Write-Host 'Could not close the transcript cleanly.'
        }
    }
}

exit $exitCode
